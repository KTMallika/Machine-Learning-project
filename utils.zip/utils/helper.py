from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

def load_data():
    iris = load_iris()
    return iris.data, iris.target, iris.target_names, iris.feature_names

def train_model(X, y, k):
    xtrain, xtest, ytrain, ytest = train_test_split(
        X, y, test_size=0.3, random_state=1
    )

    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(xtrain, ytrain)

    pred = model.predict(xtest)
    acc = accuracy_score(ytest, pred)

    return model, xtest, ytest, pred, acc