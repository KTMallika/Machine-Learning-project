import streamlit as st
from utils.helper import load_data, train_model
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

st.title("📊 Analytics Dashboard")

# =========================
# LOAD DATA
# =========================
X, y, names, _ = load_data()

# =========================
# TRAIN MODEL
# =========================
model, xtest, ytest, pred, acc = train_model(X, y, 3)

# =========================
# ACCURACY
# =========================
st.metric("Accuracy", f"{acc*100:.2f}%")

# =========================
# CONFUSION MATRIX
# =========================
st.subheader("Confusion Matrix")

cm = confusion_matrix(ytest, pred)

fig, ax = plt.subplots()
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=names,
            yticklabels=names)

st.pyplot(fig)

# =========================
# ACTUAL VS PREDICTED TABLE
# =========================
st.subheader("Actual vs Predicted")

df = pd.DataFrame({
    "Actual": [names[i] for i in ytest],
    "Predicted": [names[i] for i in pred]
})

df["Result"] = np.where(df["Actual"] == df["Predicted"], "Correct", "Wrong")

st.dataframe(df)

# =========================
# 🥧 PIE CHART (CORRECT VS WRONG)
# =========================
st.subheader("Prediction Result Distribution")

correct = sum(df["Result"] == "Correct")
wrong = sum(df["Result"] == "Wrong")

fig1, ax1 = plt.subplots()
ax1.pie([correct, wrong],
        labels=["Correct", "Wrong"],
        autopct='%1.1f%%')
ax1.set_title("Correct vs Wrong Predictions")

st.pyplot(fig1)

# =========================
# 📊 BAR CHART (CLASS DISTRIBUTION)
# =========================
st.subheader("Class Distribution")

class_counts = pd.Series(df["Actual"]).value_counts()

fig2, ax2 = plt.subplots()
class_counts.plot(kind='bar', ax=ax2)

ax2.set_xlabel("Flower Type")
ax2.set_ylabel("Count")
ax2.set_title("Actual Class Count")

st.pyplot(fig2)